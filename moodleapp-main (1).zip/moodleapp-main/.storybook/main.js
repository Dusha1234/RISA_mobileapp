module.exports = {
    framework: '@storybook/angular',
    addons: ['@storybook/addon-controls'],
    stories: ['../src/**/*.stories.ts'],
}
