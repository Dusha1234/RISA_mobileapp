import '!style-loader!css-loader!sass-loader!../src/theme/theme.design-system.scss';
import '!style-loader!css-loader!sass-loader!./styles.scss';

export const parameters = {
    layout: 'centered',
};
